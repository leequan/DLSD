
#include <QtWidgets>

#include "pages.h"
#include "subconfigdialog.h"
#include "configdialog.h"

//对地检测子类实现
SubGroundPage1::SubGroundPage1(QWidget *parent)
    : QWidget(parent)
{

    QListWidget *SubGroundBrief1 = new QListWidget;
    QListWidgetItem *SubGroundBriefTxt1 = new QListWidgetItem(SubGroundBrief1);
    SubGroundBriefTxt1->setText(tr("SubGroundPage1  "));

    SubGroundPage1fileComboBox = SubGroundPage1createComboBox(tr("*"));

    QPushButton *SubGroundstartButton1 = new QPushButton(tr("运行"));
    QObject::connect(SubGroundstartButton1,SIGNAL(clicked()),this, SLOT(SubGroundstartButton_clicked1()));


     QGridLayout *SubGroundmainLayout1 = new QGridLayout;
     SubGroundmainLayout1->addWidget(SubGroundBrief1,0,0,1,2);
     SubGroundmainLayout1->addWidget(SubGroundPage1fileComboBox,1,0,1,1);
     SubGroundmainLayout1->addWidget(SubGroundstartButton1,1,1,1,1);
     setLayout(SubGroundmainLayout1);
}

void SubGroundPage1::SubGroundstartButton_clicked1()
{
//    system("/home/jalywangtuxiang/Downloads/detect_track_0904_yangdong ");

      QString SubGroundPage1fileName = "/home/jalywangtuxiang/liquan/arguments ";
      SubGroundPage1fileName += SubGroundPage1fileComboBox->currentText();
      SubGroundPage1fileName += path;

     qDebug() << SubGroundPage1fileName<<endl;

     char* program;
     QByteArray ba = SubGroundPage1fileName.toLatin1();
     program = ba.data();
     system(program);

     //    system("/home/jalywangtuxiang/liquan/arguments -a1 123 -a2 562 ");
}

void SubGroundPage1::getPath(QString ipath)
{
    path = ipath;
    qDebug() << path<<endl;
}

SubGroundPage2::SubGroundPage2(QWidget *parent)
    : QWidget(parent)
{

    QListWidget *SubGroundBrief2 = new QListWidget;
    QListWidgetItem *SubGroundBriefTxt2 = new QListWidgetItem(SubGroundBrief2);
    SubGroundBriefTxt2->setText(tr("SubGroundPage2  "));


    QLineEdit *SubGroundedit2 = new QLineEdit;

    QPushButton *SubGroundstartButton2 = new QPushButton(tr("运行"));
    QObject::connect(SubGroundstartButton2,SIGNAL(clicked()),this, SLOT(SubGroundstartButton_clicked2()));


     QGridLayout *SubGroundmainLayout2 = new QGridLayout;
     SubGroundmainLayout2->addWidget(SubGroundBrief2,0,0,1,2);
     SubGroundmainLayout2->addWidget(SubGroundedit2,1,0,1,1);
     SubGroundmainLayout2->addWidget(SubGroundstartButton2,1,1,1,1);
     setLayout(SubGroundmainLayout2);
}
void SubGroundPage2::SubGroundstartButton_clicked2()
{
    system("/home/jalywangtuxiang/Downloads/detect_track_0904_yangdong ");
}


SubGroundPage3::SubGroundPage3(QWidget *parent)
    : QWidget(parent)
{

    QListWidget *SubGroundBrief3 = new QListWidget;
    QListWidgetItem *SubGroundBriefTxt3 = new QListWidgetItem(SubGroundBrief3);
    SubGroundBriefTxt3->setText(tr("SubGroundPage3  "));


    QLineEdit *SubGroundedit3 = new QLineEdit;

    QPushButton *SubGroundstartButton3 = new QPushButton(tr("运行"));
    QObject::connect(SubGroundstartButton3,SIGNAL(clicked()),this, SLOT(SubGroundstartButton_clicked3()));


     QGridLayout *SubGroundmainLayout3 = new QGridLayout;
     SubGroundmainLayout3->addWidget(SubGroundBrief3,0,0,1,2);
     SubGroundmainLayout3->addWidget(SubGroundedit3,1,0,1,1);
     SubGroundmainLayout3->addWidget(SubGroundstartButton3,1,1,1,1);
     setLayout(SubGroundmainLayout3);
}
void SubGroundPage3::SubGroundstartButton_clicked3()
{
    system("/home/jalywangtuxiang/Downloads/detect_track_0904_yangdong ");
}

SubGroundPage4::SubGroundPage4(QWidget *parent)
    : QWidget(parent)
{

    QListWidget *SubGroundBrief4 = new QListWidget;
    QListWidgetItem *SubGroundBriefTxt4 = new QListWidgetItem(SubGroundBrief4);
    SubGroundBriefTxt4->setText(tr("SubGroundPage4  "));


    QLineEdit *SubGroundedit4 = new QLineEdit;

    QPushButton *SubGroundstartButton4 = new QPushButton(tr("运行"));
    QObject::connect(SubGroundstartButton4,SIGNAL(clicked()),this, SLOT(SubGroundstartButton_clicked4()));


     QGridLayout *SubGroundmainLayout4 = new QGridLayout;
     SubGroundmainLayout4->addWidget(SubGroundBrief4,0,0,1,2);
     SubGroundmainLayout4->addWidget(SubGroundedit4,1,0,1,1);
     SubGroundmainLayout4->addWidget(SubGroundstartButton4,1,1,1,1);
     setLayout(SubGroundmainLayout4);
}

void SubGroundPage4::SubGroundstartButton_clicked4()
{
    system("/home/jalywangtuxiang/Downloads/detect_track_0904_yangdong ");
}


SubGroundPage5::SubGroundPage5(QWidget *parent)
    : QWidget(parent)
{

    QListWidget *SubGroundBrief5 = new QListWidget;
    QListWidgetItem *SubGroundBriefTxt5 = new QListWidgetItem(SubGroundBrief5);
    SubGroundBriefTxt5->setText(tr("SubGroundPage5  "));


    QLineEdit *SubGroundedit5 = new QLineEdit;

    QPushButton *SubGroundstartButton5 = new QPushButton(tr("运行"));
    QObject::connect(SubGroundstartButton5,SIGNAL(clicked()),this, SLOT(SubGroundstartButton_clicked5()));


     QGridLayout *SubGroundmainLayout5 = new QGridLayout;
     SubGroundmainLayout5->addWidget(SubGroundBrief5,0,0,1,2);
     SubGroundmainLayout5->addWidget(SubGroundedit5,1,0,1,1);
     SubGroundmainLayout5->addWidget(SubGroundstartButton5,1,1,1,1);
     setLayout(SubGroundmainLayout5);
}
void SubGroundPage5::SubGroundstartButton_clicked5()
{
    system("/home/jalywangtuxiang/Downloads/detect_track_0905_yangdong ");
}



//对空检测子类实现
SubSkyPage1::SubSkyPage1(QWidget *parent)
    : QWidget(parent)
{

    QListWidget *SubSkyBrief1 = new QListWidget;
    QListWidgetItem *SubSkyBriefTxt1 = new QListWidgetItem(SubSkyBrief1);
    SubSkyBriefTxt1->setText(tr("SubSkyPage1  "));


    QLineEdit *SubSkyedit1 = new QLineEdit;

    QPushButton *SubSkystartButton1 = new QPushButton(tr("运行"));
    QObject::connect(SubSkystartButton1,SIGNAL(clicked()),this, SLOT(SubSkystartButton_clicked1()));


     QGridLayout *SubSkymainLayout1 = new QGridLayout;
     SubSkymainLayout1->addWidget(SubSkyBrief1,0,0,1,2);
     SubSkymainLayout1->addWidget(SubSkyedit1,1,0,1,1);
     SubSkymainLayout1->addWidget(SubSkystartButton1,1,1,1,1);
     setLayout(SubSkymainLayout1);
}

void SubSkyPage1::SubSkystartButton_clicked1()
{
    system("/home/jalywangtuxiang/Downloads/detect_track_0904_yangdong ");
}


SubSkyPage2::SubSkyPage2(QWidget *parent)
    : QWidget(parent)
{

    QListWidget *SubSkyBrief2 = new QListWidget;
    QListWidgetItem *SubSkyBriefTxt2 = new QListWidgetItem(SubSkyBrief2);
    SubSkyBriefTxt2->setText(tr("SubSkyPage2  "));


    QLineEdit *SubSkyedit2 = new QLineEdit;

    QPushButton *SubSkystartButton2 = new QPushButton(tr("运行"));
    QObject::connect(SubSkystartButton2,SIGNAL(clicked()),this, SLOT(SubSkystartButton_clicked2()));


     QGridLayout *SubSkymainLayout2 = new QGridLayout;
     SubSkymainLayout2->addWidget(SubSkyBrief2,0,0,1,2);
     SubSkymainLayout2->addWidget(SubSkyedit2,1,0,1,1);
     SubSkymainLayout2->addWidget(SubSkystartButton2,1,1,1,1);
     setLayout(SubSkymainLayout2);

}

void SubSkyPage2::SubSkystartButton_clicked2()
{
    system("/home/jalywangtuxiang/Downloads/detect_track_0904_yangdong ");
}

QComboBox *SubGroundPage1::SubGroundPage1createComboBox(const QString &text)
{
    QComboBox *comboBox = new QComboBox;
    comboBox->setEditable(true);
    comboBox->addItem(text);
    comboBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    return comboBox;
}
