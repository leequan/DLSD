#ifndef SUBCONFIGDIALOG_H
#define SUBCONFIGDIALOG_H

#include <QWidget>
#include <QDir>
#include <QDialog>

QT_BEGIN_NAMESPACE
class QComboBox;
class QLabel;
class QPushButton;
class QTableWidget;
class QTableWidgetItem;
class QListWidget;
class QListWidgetItem;
class QStackedWidget;
QT_END_NAMESPACE

//对地检测子类定义
class SubGroundPage1 : public QWidget
{
     Q_OBJECT

public:
     SubGroundPage1(QWidget *parent = 0);
public slots:
    void SubGroundstartButton_clicked1();
    void getPath(QString path);
private:

    QComboBox *SubGroundPage1createComboBox(const QString &text = QString());
    QComboBox *SubGroundPage1fileComboBox;
    QString path;

};

class SubGroundPage2 : public QWidget
{
     Q_OBJECT

public:
    SubGroundPage2(QWidget *parent = 0);
public slots:
    void SubGroundstartButton_clicked2();
};

class SubGroundPage3 : public QWidget
{
    Q_OBJECT

public:
    SubGroundPage3(QWidget *parent = 0);
public slots:
    void SubGroundstartButton_clicked3();
};


class SubGroundPage4 : public QWidget
{
    Q_OBJECT

public:
    SubGroundPage4(QWidget *parent = 0);
public slots:
    void SubGroundstartButton_clicked4();
};

class SubGroundPage5 : public QWidget
{
    Q_OBJECT

public:
    SubGroundPage5(QWidget *parent = 0);
public slots:
    void SubGroundstartButton_clicked5();
};

//对空检测子类定义
class SubSkyPage1 : public QWidget
{
     Q_OBJECT

public:
    SubSkyPage1(QWidget *parent = 0);
public slots:
    void SubSkystartButton_clicked1();
};

class SubSkyPage2 : public QWidget
{
     Q_OBJECT

public:
    SubSkyPage2(QWidget *parent = 0);
public slots:
    void SubSkystartButton_clicked2();
};

//软件简介及使用方法
class SubBriefPage : public QWidget
{
    Q_OBJECT

public:
    SubBriefPage(QWidget *parent = 0);

};

#endif
