#ifndef TEXTREADING_H
#define TEXTREADING_H

#include <QMainWindow>
#include <QString>
#include <QFile>
#include <QFileInfo>
#include <QFileDialog>

#include <QTextStream> //�ļ���
#include <QMessageBox> //��������

namespace Ui {
class textreading;
}

class textreading : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit textreading(QWidget *parent = 0);
    ~textreading();

    QString file_full, file_name, file_path;
    QFileInfo fi;
    
private slots:
    void on_openBtn_clicked();

    void initSlots();
    void showSlots();

    void on_showBtn_clicked();

    void on_textBrowser_textChanged();


private:
    Ui::textreading *ui;
};

#endif // TEXTREADING_H
