#include "textreading.h"
#include "ui_textreading.h"
#include <QStringListModel>
#include <QDebug>
#include <QTextCodec>

textreading::textreading(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::textreading)
{
    ui->setupUi(this);
}



textreading::~textreading()
{
    delete ui;
}
void textreading::initSlots()
{
    //�������򿪡������ź���۵�����
    connect(ui->openBtn,SIGNAL(clicked()),SLOT(openBtn_Clicked()));
}

//open ����
void textreading::on_openBtn_clicked()
{
     // QString file_full, file_name, file_path;
     // QFileInfo fi;
  //    file_full = QFileDialog::getOpenFileNames(this);
      file_full = QFileDialog::getOpenFileName(this,tr("open"),".",tr("Text Files(*.txt)"));

      fi = QFileInfo(file_full);
      file_name = fi.fileName();
      file_path = fi.absolutePath();
      ui->textEdit->setText(file_path+""+file_name);//?
}

 void textreading:: showSlots()
 {
     connect(ui->showBtn,SIGNAL(clicked()),SLOT(showBtn_clicked()));
 }

void textreading::on_showBtn_clicked()
{

/*    QStringList user;

    user<<file_full;

    QStringListModel *model = new QStringListModel(user);
    ui->listView->setModel(model);
 */
  QFile file(file_full);
    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
         QMessageBox::warning(this, tr("Application"),
                                 tr("Cannot read file %1:\n%2.")
                              .arg(file_full)
                                 .arg(file.errorString()));
         return;
    }
    QTextStream in(&file);
    ui->textBrowser->setPlainText(in.readAll());
    file.close();



}

void textreading::on_textBrowser_textChanged()
{
    ui->textBrowser->moveCursor(QTextCursor::End);
}

