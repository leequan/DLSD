/****************************************************************************
** Meta object code from reading C++ file 'textreading.h'
**
** Created: Wed Apr 10 15:08:49 2013
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../textreading.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'textreading.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_textreading[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      13,   12,   12,   12, 0x08,
      34,   12,   12,   12, 0x08,
      46,   12,   12,   12, 0x08,
      58,   12,   12,   12, 0x08,
      79,   12,   12,   12, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_textreading[] = {
    "textreading\0\0on_openBtn_clicked()\0"
    "initSlots()\0showSlots()\0on_showBtn_clicked()\0"
    "on_textBrowser_textChanged()\0"
};

void textreading::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        textreading *_t = static_cast<textreading *>(_o);
        switch (_id) {
        case 0: _t->on_openBtn_clicked(); break;
        case 1: _t->initSlots(); break;
        case 2: _t->showSlots(); break;
        case 3: _t->on_showBtn_clicked(); break;
        case 4: _t->on_textBrowser_textChanged(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData textreading::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject textreading::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_textreading,
      qt_meta_data_textreading, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &textreading::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *textreading::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *textreading::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_textreading))
        return static_cast<void*>(const_cast< textreading*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int textreading::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
