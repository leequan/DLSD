/********************************************************************************
** Form generated from reading UI file 'textreading.ui'
**
** Created: Wed Apr 10 16:08:29 2013
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TEXTREADING_H
#define UI_TEXTREADING_H

#include <QtCore/QVariant>
#include <QAction>
#include <QApplication>
#include <QButtonGroup>
#include <QHeaderView>
#include <QLabel>
#include <QMainWindow>
#include <QMenuBar>
#include <QPushButton>
#include <QStatusBar>
#include <QTextBrowser>
#include <QTextEdit>
#include <QToolBar>
#include <QWidget>

QT_BEGIN_NAMESPACE

class Ui_textreading
{
public:
    QWidget *centralWidget;
    QPushButton *openBtn;
    QPushButton *showBtn;
    QTextEdit *textEdit;
    QTextBrowser *textBrowser;
    QLabel *label;
    QLabel *label_2;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *textreading)
    {
        if (textreading->objectName().isEmpty())
            textreading->setObjectName(QString::fromUtf8("textreading"));
        textreading->resize(640, 446);
        centralWidget = new QWidget(textreading);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        openBtn = new QPushButton(centralWidget);
        openBtn->setObjectName(QString::fromUtf8("openBtn"));
        openBtn->setGeometry(QRect(500, 50, 75, 23));
        QFont font;
        font.setFamily(QString::fromUtf8("Times New Roman"));
        font.setPointSize(14);
        openBtn->setFont(font);
        showBtn = new QPushButton(centralWidget);
        showBtn->setObjectName(QString::fromUtf8("showBtn"));
        showBtn->setGeometry(QRect(500, 190, 75, 23));
        showBtn->setFont(font);
        textEdit = new QTextEdit(centralWidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(110, 40, 381, 41));
        textBrowser = new QTextBrowser(centralWidget);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(110, 100, 381, 261));
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 50, 101, 21));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\346\226\260\345\256\213\344\275\223"));
        font1.setPointSize(14);
        label->setFont(font1);
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 190, 91, 41));
        label_2->setFont(font1);
        textreading->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(textreading);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 640, 23));
        textreading->setMenuBar(menuBar);
        mainToolBar = new QToolBar(textreading);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        textreading->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(textreading);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        textreading->setStatusBar(statusBar);

        retranslateUi(textreading);

        QMetaObject::connectSlotsByName(textreading);
    } // setupUi

    void retranslateUi(QMainWindow *textreading)
    {
        textreading->setWindowTitle(QApplication::translate("textreading", "textreading", 0));
        openBtn->setText(QApplication::translate("textreading", "open", 0));
        showBtn->setText(QApplication::translate("textreading", "show", 0));
        label->setText(QApplication::translate("textreading", "\351\200\211\346\213\251\346\226\207\344\273\266\357\274\232", 0));
        label_2->setText(QApplication::translate("textreading", "\350\257\246\347\273\206\344\277\241\346\201\257\357\274\232", 0)); //, QApplication::UnicodeUTF8
    } // retranslateUi

};

namespace Ui {
    class textreading: public Ui_textreading {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TEXTREADING_H
