#include <QApplication>
#include "textreading.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    textreading w;
    w.show();
    
    return a.exec();
}
