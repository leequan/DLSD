#include "buttonmenu.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	ButtonMenu w;
	w.show();
	return a.exec();
}
