#ifndef BUTTONMENU_H
#define BUTTONMENU_H

#pragma execution_character_set("utf-8")

#include <QtWidgets/QWidget>
#include <QtWidgets/QPushButton>
#include <QMenu>

class ButtonMenu : public QWidget
{
	Q_OBJECT

public:
	ButtonMenu(QWidget *parent = 0);
	~ButtonMenu();

private:
	void addFunc();
	void delFunc();

	QPushButton *m_pushButton;

	QMenu *m_menu;
	QAction *m_addAction;
	QAction *m_delAction;
	QAction *m_subAction;//�˶�����ʾ�Ӳ˵�

	QMenu *m_subMenu;//�Ӳ˵�
	QAction *m_subAdd;
	QAction *m_subDel;
};

#endif // BUTTONMENU_H
