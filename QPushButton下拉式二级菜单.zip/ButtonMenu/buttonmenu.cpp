#include "buttonmenu.h"
#include <QDebug>

ButtonMenu::ButtonMenu(QWidget *parent)
	: QWidget(parent)
{
	m_menu = new QMenu(this);
	m_addAction = new QAction(m_menu);
	m_subAction = new QAction(m_menu);
	m_delAction = new QAction(m_menu);
	m_addAction->setCheckable(true);//�Ƿ����check
	m_delAction->setCheckable(true);//�Ƿ����check
	m_addAction->setText(QObject::tr("����"));
	m_subAction->setText(QObject::tr("�Ӳ˵�"));
	m_delAction->setText(QObject::tr("ɾ��"));
	m_menu->addAction(m_addAction);
	m_menu->addAction(m_delAction);
	m_menu->addAction(m_subAction);
	connect(m_addAction, &QAction::triggered, this, &ButtonMenu::addFunc);
	connect(m_delAction, &QAction::triggered, this, &ButtonMenu::delFunc);

	m_subMenu = new QMenu(this);
	m_subAdd = new QAction(m_subMenu);
	m_subDel = new QAction(m_subMenu);
	m_subAdd->setText(QObject::tr("������"));
	m_subDel->setText(QObject::tr("��ɾ��"));
	m_subMenu->addAction(m_subAdd);
	m_subMenu->addAction(m_subDel);
	m_subAction->setMenu(m_subMenu);

	m_pushButton = new QPushButton(this);
	m_pushButton->setText(QObject::tr("���԰�ť�˵�"));
	m_pushButton->setMenu(m_menu);//���ò˵�

	//m_pushButton->setStyleSheet("QPushButton::menu-indicator{image:none;}");//����ʾ����ͼƬ
}

ButtonMenu::~ButtonMenu()
{

}

void ButtonMenu::addFunc()
{
	qDebug() << "addFunc";
}

void ButtonMenu::delFunc()
{
	qDebug() << "delFunc";
}