#include <QtWidgets>

#include "pages.h"
#include "subskypage.h"
#include "configdialog.h"

//对空检测子类实现
SubSkyPage1::SubSkyPage1(QWidget *parent)
    : QWidget(parent)
{

    QTextBrowser *textBrowserSubSkyPage1 = new QTextBrowser;
    QString file_fullSubSkyPage1 = ":/txt/SkyDetection1/KCF_SkyDetection.txt";
    QFile file(file_fullSubSkyPage1);
       if (!file.open(QFile::ReadOnly | QFile::Text))
          {
               QMessageBox::warning(this, tr("Application"),
                                       tr("Cannot read file %1:\n%2.")
                                    .arg(file_fullSubSkyPage1)
                                       .arg(file.errorString()));
               return;
          }
          QTextStream in(&file);
          textBrowserSubSkyPage1->setPlainText(in.readAll());
          file.close();

    SubSkyedit1 = SubSkyPage1createLineEdit(tr(""));

    QPushButton *SubSkystartButton1 = new QPushButton(tr("运行"));
    QObject::connect(SubSkystartButton1,SIGNAL(clicked()),this, SLOT(SubSkystartButton_clicked1()));


     QGridLayout *SubSkymainLayout1 = new QGridLayout;
     SubSkymainLayout1->addWidget(textBrowserSubSkyPage1,0,0,1,2);
     SubSkymainLayout1->addWidget(SubSkyedit1,1,0,1,1);
     SubSkymainLayout1->addWidget(SubSkystartButton1,1,1,1,1);
     setLayout(SubSkymainLayout1);
}

void SubSkyPage1::SubSkystartButton_clicked1()
{
     QString SubSky1fileName = "/home/jalywangtuxiang/QtProjects/DeepLearningSystemdialog/program/arguments ";
     SubSky1fileName += SubSkyedit1->text();
     SubSky1fileName += pathSubSkyPage1;

     char* program;
     QByteArray ba = SubSky1fileName.toLatin1();
     program = ba.data();
     system(program);
}

void SubSkyPage1::getPathSubSkyPage1(QString ipathSubSkyPage1)
{
    pathSubSkyPage1 = ipathSubSkyPage1;
}

QLineEdit *SubSkyPage1::SubSkyPage1createLineEdit(const QString &text)
{
    QLineEdit *LineEditSubSkyPage1 = new QLineEdit;
    LineEditSubSkyPage1->setText(text);
    return LineEditSubSkyPage1;
}


SubSkyPage2::SubSkyPage2(QWidget *parent)
    : QWidget(parent)
{

    QTextBrowser *textBrowserSubSkyPage2 = new QTextBrowser;
    QString file_fullSubSkyPage2 = ":/txt/SkyDetection2/NCC_SkyDetection.txt";
    QFile file(file_fullSubSkyPage2);
          if (!file.open(QFile::ReadOnly | QFile::Text))
          {
               QMessageBox::warning(this, tr("Application"),
                                       tr("Cannot read file %2:\n%2.")
                                    .arg(file_fullSubSkyPage2)
                                       .arg(file.errorString()));
               return;
          }
          QTextStream in(&file);
          textBrowserSubSkyPage2->setPlainText(in.readAll());
          file.close();
    SubSkyedit2 = SubSkyPage2createLineEdit(tr(""));

    QPushButton *SubSkystartButton2 = new QPushButton(tr("运行"));
    QObject::connect(SubSkystartButton2,SIGNAL(clicked()),this, SLOT(SubSkystartButton_clicked2()));


     QGridLayout *SubSkymainLayout2 = new QGridLayout;
     SubSkymainLayout2->addWidget(textBrowserSubSkyPage2,0,0,1,2);
     SubSkymainLayout2->addWidget(SubSkyedit2,1,0,1,1);
     SubSkymainLayout2->addWidget(SubSkystartButton2,1,1,1,1);
     setLayout(SubSkymainLayout2);
}

void SubSkyPage2::SubSkystartButton_clicked2()
{
     QString SubSky2fileName = "/home/jalywangtuxiang/QtProjects/DeepLearningSystemdialog/program/arguments ";
     SubSky2fileName += SubSkyedit2->text();
     SubSky2fileName += pathSubSkyPage2;

     char* program;
     QByteArray ba = SubSky2fileName.toLatin1();
     program = ba.data();
     system(program);
}

void SubSkyPage2::getPathSubSkyPage2(QString ipathSubSkyPage2)
{
    pathSubSkyPage2 = ipathSubSkyPage2;
}

QLineEdit *SubSkyPage2::SubSkyPage2createLineEdit(const QString &text)
{
    QLineEdit *LineEditSubSkyPage2 = new QLineEdit;
    LineEditSubSkyPage2->setText(text);
    return LineEditSubSkyPage2;
}


