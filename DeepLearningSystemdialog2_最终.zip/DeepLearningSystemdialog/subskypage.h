#ifndef SUBSKYPAGE
#define SUBSKYPAGE

#include <QWidget>

QT_BEGIN_NAMESPACE
class QLineEdit;
QT_END_NAMESPACE

//对空检测跟踪子类定义
class SubSkyPage1 : public QWidget
{
     Q_OBJECT

public:
    SubSkyPage1(QWidget *parent = 0);

public slots:
    void SubSkystartButton_clicked1();
    void getPathSubSkyPage1(QString pathSubSkyPage1);

private:
        QLineEdit *SubSkyPage1createLineEdit(const QString &text = QString());
        QLineEdit *SubSkyedit1;
        QString pathSubSkyPage1;
};

class SubSkyPage2 : public QWidget
{
     Q_OBJECT

public:
    SubSkyPage2(QWidget *parent = 0);

public slots:
    void SubSkystartButton_clicked2();
    void getPathSubSkyPage2(QString pathSubSkyPage1);

private:
        QLineEdit *SubSkyPage2createLineEdit(const QString &text = QString());
        QLineEdit *SubSkyedit2;
        QString pathSubSkyPage2;
};
#endif // SUBSKYPAGE

